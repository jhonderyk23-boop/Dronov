-- STUDIO DRONOV | Supabase setup
-- Execute no SQL Editor do projeto Supabase.
-- Crie também o usuário do tatuador em Authentication > Users.

create extension if not exists pgcrypto;

create table if not exists public.studio_settings (
  id integer primary key default 1 check (id = 1),
  artist_name text,
  whatsapp text,
  instagram text,
  address text,
  years_experience integer not null default 0 check (years_experience between 0 and 80),
  specialties text,
  short_bio text,
  bio text,
  hero_image_url text,
  about_image_url text,
  deposit_amount numeric(10,2) not null default 0 check (deposit_amount >= 0),
  deposit_mode text not null default 'informational' check (deposit_mode in ('informational','manual','online_later')),
  updated_at timestamptz not null default now()
);

create table if not exists public.portfolio (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null default 'Outros',
  content_type text not null default 'tattoo' check (content_type in ('tattoo','art')),
  description text,
  image_url text not null,
  is_published boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

-- Compatibilidade com banco criado antes da separação entre tatuagens e artes autorais.
alter table public.portfolio add column if not exists content_type text not null default 'tattoo';
alter table public.portfolio drop constraint if exists portfolio_content_type_check;
alter table public.portfolio add constraint portfolio_content_type_check check (content_type in ('tattoo','art','piercing'));

create table if not exists public.availability (
  id uuid primary key default gen_random_uuid(),
  available_date date not null unique,
  start_time time not null,
  end_time time not null,
  is_open boolean not null default true,
  is_public boolean not null default true,
  default_duration_minutes integer not null default 60 check (default_duration_minutes between 15 and 1440),
  slot_interval_minutes integer not null default 30 check (slot_interval_minutes between 5 and 240),
  note text,
  created_at timestamptz not null default now(),
  constraint availability_time_valid check (end_time > start_time)
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  email text,
  booking_date date not null,
  start_time time not null,
  service_type text not null default 'tattoo',
  piercing_type text,
  duration_minutes integer not null default 60 check (duration_minutes between 15 and 1440),
  style text,
  body_location text,
  size_description text,
  reference_url text,
  description text,
  status text not null default 'pending' check (status in ('pending','confirmed','reschedule_pending','completed','cancelled','rejected')),
  proposed_date date,
  proposed_time time,
  admin_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.availability add column if not exists is_public boolean not null default true;
alter table public.bookings add column if not exists service_type text not null default 'tattoo';
alter table public.bookings add column if not exists reference_path text;
alter table public.bookings add column if not exists piercing_type text;
alter table public.bookings drop constraint if exists bookings_service_type_check;
alter table public.bookings add constraint bookings_service_type_check check (service_type in ('tattoo','piercing'));

create table if not exists public.studio_notifications (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid references public.bookings(id) on delete cascade,
  title text not null,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists bookings_date_status_idx on public.bookings(booking_date,status);
create index if not exists bookings_phone_idx on public.bookings(phone);
create index if not exists availability_date_idx on public.availability(available_date);
create index if not exists portfolio_published_sort_idx on public.portfolio(is_published,sort_order);

alter table public.studio_settings enable row level security;
alter table public.portfolio enable row level security;
alter table public.availability enable row level security;
alter table public.bookings enable row level security;
alter table public.studio_notifications enable row level security;

-- Autorização real do painel: autenticação sozinha NÃO significa administrador.
-- Defina app_metadata.studio_role = "admin" apenas no usuário proprietário,
-- em Authentication > Users > (usuário) > Raw App Meta Data.
create or replace function public.is_studio_admin()
returns boolean
language sql
stable
security invoker
set search_path = pg_catalog
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'studio_role') = 'admin', false);
$$;
revoke all on function public.is_studio_admin() from public;
grant execute on function public.is_studio_admin() to anon, authenticated;

-- Configurações e portfólio: leitura pública; escrita somente autenticada.
drop policy if exists "public read studio settings" on public.studio_settings;
create policy "public read studio settings" on public.studio_settings for select using (true);
drop policy if exists "admin manage studio settings" on public.studio_settings;
create policy "admin manage studio settings" on public.studio_settings for all to authenticated using (public.is_studio_admin()) with check (public.is_studio_admin());

drop policy if exists "public read published portfolio" on public.portfolio;
create policy "public read published portfolio" on public.portfolio for select using (is_published = true or public.is_studio_admin());
drop policy if exists "admin manage portfolio" on public.portfolio;
create policy "admin manage portfolio" on public.portfolio for all to authenticated using (public.is_studio_admin()) with check (public.is_studio_admin());

-- Disponibilidade publicada no site somente para consulta; administração autenticada. Dias fechados podem ser exibidos como indisponíveis.
drop policy if exists "public read open availability" on public.availability;
create policy "public read open availability" on public.availability for select using (is_public = true or public.is_studio_admin());
drop policy if exists "admin manage availability" on public.availability;
create policy "admin manage availability" on public.availability for all to authenticated using (public.is_studio_admin()) with check (public.is_studio_admin());

-- Dados de clientes nunca são expostos por SELECT público.
drop policy if exists "admin read bookings" on public.bookings;
create policy "admin read bookings" on public.bookings for select to authenticated using (public.is_studio_admin());
drop policy if exists "admin update bookings" on public.bookings;
create policy "admin update bookings" on public.bookings for update to authenticated using (public.is_studio_admin()) with check (public.is_studio_admin());

-- Notificações somente no painel autenticado.
drop policy if exists "admin manage notifications" on public.studio_notifications;
create policy "admin manage notifications" on public.studio_notifications for all to authenticated using (public.is_studio_admin()) with check (public.is_studio_admin());

-- A função pública valida disponibilidade e impede duas solicitações que se sobreponham.
-- A reserva criada permanece pendente e não é uma confirmação de atendimento.
create or replace function public.create_public_booking(p_booking jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_date date;
  v_time time;
  v_duration integer;
  v_av availability%rowtype;
  v_id uuid;
  v_name text;
  v_phone text;
  v_service text;
begin
  v_name := nullif(trim(p_booking->>'customer_name'),'');
  v_phone := nullif(trim(p_booking->>'phone'),'');
  v_service := coalesce(nullif(trim(p_booking->>'service_type'),''),'tattoo');
  if v_service not in ('tattoo','piercing') then
    return jsonb_build_object('success',false,'message','Tipo de atendimento inválido.');
  end if;
  if v_name is null or length(v_name) > 100 or v_phone is null or length(v_phone) > 30 then
    return jsonb_build_object('success',false,'message','Informe nome e WhatsApp válidos.');
  end if;
  if v_service='piercing' and nullif(trim(p_booking->>'piercing_type'),'') is null then
    return jsonb_build_object('success',false,'message','Informe qual piercing deseja realizar.');
  end if;
  begin
    v_date := (p_booking->>'booking_date')::date;
    v_time := (p_booking->>'start_time')::time;
  exception when others then
    return jsonb_build_object('success',false,'message','Data ou horário inválido.');
  end;
  if v_date < current_date then
    return jsonb_build_object('success',false,'message','Não é possível solicitar uma data passada.');
  end if;
  select * into v_av from public.availability where available_date=v_date and is_open=true and is_public=true;
  if not found then
    return jsonb_build_object('success',false,'message','Este dia não está disponível.');
  end if;
  v_duration := greatest(15,least(1440,coalesce(v_av.default_duration_minutes,60)));
  if v_time < v_av.start_time or v_time + make_interval(mins => v_duration) > v_av.end_time then
    return jsonb_build_object('success',false,'message','Horário fora da janela de atendimento.');
  end if;
  if mod(extract(epoch from (v_time - v_av.start_time)) / 60, v_av.slot_interval_minutes) <> 0 then
    return jsonb_build_object('success',false,'message','Escolha um dos horários publicados pelo estúdio.');
  end if;
  -- Serializa solicitações da mesma data para reduzir risco de conflito simultâneo.
  perform pg_advisory_xact_lock(hashtext(v_date::text));
  if exists (
    select 1 from public.bookings b
    where b.booking_date=v_date and b.status in ('pending','confirmed','reschedule_pending')
      and ((v_time < b.start_time + make_interval(mins => b.duration_minutes)
      and v_time + make_interval(mins => v_duration) > b.start_time)
      or (b.status='reschedule_pending' and b.proposed_date=v_date and v_time < b.proposed_time + make_interval(mins => b.duration_minutes)
      and v_time + make_interval(mins => v_duration) > b.proposed_time))
  ) then
    return jsonb_build_object('success',false,'message','Este horário acabou de ser solicitado. Escolha outro horário.');
  end if;
  insert into public.bookings(customer_name,phone,email,booking_date,start_time,duration_minutes,service_type,piercing_type,style,body_location,size_description,reference_url,reference_path,description,status)
  values(v_name,v_phone,nullif(p_booking->>'email',''),v_date,v_time,v_duration,v_service,case when v_service='piercing' then nullif(p_booking->>'piercing_type','') else null end,case when v_service='tattoo' then nullif(p_booking->>'style','') else null end,nullif(p_booking->>'body_location',''),case when v_service='tattoo' then nullif(p_booking->>'size_description','') else null end,nullif(p_booking->>'reference_url',''),nullif(p_booking->>'reference_path',''),nullif(p_booking->>'description',''),'pending')
  returning id into v_id;
  insert into public.studio_notifications(booking_id,title,message)
  values(v_id,'Nova solicitação de agendamento',v_name || ' solicitou ' || to_char(v_date,'DD/MM/YYYY') || ' às ' || to_char(v_time,'HH24:MI') || '.');
  return jsonb_build_object('success',true,'booking_id',v_id,'message','Solicitação enviada para análise.');
end;
$$;
revoke all on function public.create_public_booking(jsonb) from public;
grant execute on function public.create_public_booking(jsonb) to anon, authenticated;

-- Retorna somente horários ocupados (sem nome, telefone, e-mail ou dados do cliente).
-- Isso permite montar o calendário público sem abrir SELECT na tabela privada bookings.
create or replace function public.public_busy_slots(p_date date)
returns table(start_time time,duration_minutes integer,status text,proposed_date date,proposed_time time)
language sql
security definer
set search_path = public, pg_temp
stable
as $$
  select b.start_time,b.duration_minutes,b.status,b.proposed_date,b.proposed_time
  from public.bookings b
  where b.status in ('pending','confirmed','reschedule_pending')
    and (b.booking_date=p_date or (b.status='reschedule_pending' and b.proposed_date=p_date));
$$;
revoke all on function public.public_busy_slots(date) from public;
grant execute on function public.public_busy_slots(date) to anon, authenticated;

-- Ações administrativas; somente usuário autenticado.
create or replace function public.admin_update_booking(
  p_booking_id uuid,
  p_status text,
  p_new_date date default null,
  p_new_time time default null,
  p_duration integer default null,
  p_notes text default null
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_b public.bookings%rowtype;
  v_target_date date;
  v_target_time time;
  v_target_duration integer;
begin
  if not public.is_studio_admin() then raise exception 'Acesso administrativo não autorizado.'; end if;
  if p_status not in ('confirmed','reschedule_pending','completed','cancelled','rejected') then
    raise exception 'Status inválido.';
  end if;
  if p_duration is not null and (p_duration < 15 or p_duration > 1440) then
    raise exception 'A duração deve estar entre 15 e 1440 minutos.';
  end if;

  select * into v_b from public.bookings where id=p_booking_id for update;
  if not found then raise exception 'Agendamento não encontrado.'; end if;

  if p_status='reschedule_pending' then
    if p_new_date is null or p_new_time is null then
      raise exception 'Informe a nova data e horário.';
    end if;
    update public.bookings
      set status=p_status, proposed_date=p_new_date, proposed_time=p_new_time,
          duration_minutes=coalesce(p_duration,duration_minutes),
          admin_notes=coalesce(p_notes,admin_notes), updated_at=now()
      where id=p_booking_id;
    insert into public.studio_notifications(booking_id,title,message)
      values(p_booking_id,'Nova data proposta','O tatuador propôs '||to_char(p_new_date,'DD/MM/YYYY')||' às '||to_char(p_new_time,'HH24:MI')||'.');
  else
    if p_status='confirmed' then
      -- Confirma a data/horário propostos quando existe remarcação; senão, mantém o pedido original.
      v_target_date := case when v_b.status='reschedule_pending' and v_b.proposed_date is not null then v_b.proposed_date else v_b.booking_date end;
      v_target_time := case when v_b.status='reschedule_pending' and v_b.proposed_time is not null then v_b.proposed_time else v_b.start_time end;
      v_target_duration := coalesce(p_duration,v_b.duration_minutes);
      perform pg_advisory_xact_lock(hashtext(v_target_date::text));

      -- Não permite aprovar uma sessão que se sobreponha a outro pedido, reserva
      -- confirmada ou horário proposto por outra remarcação, inclusive se a duração aumentou.
      if exists (
        select 1
        from public.bookings x
        where x.id<>p_booking_id
          and x.status in ('pending','confirmed','reschedule_pending')
          and (
            (x.booking_date=v_target_date
              and v_target_time < x.start_time + make_interval(mins => x.duration_minutes)
              and v_target_time + make_interval(mins => v_target_duration) > x.start_time)
            or
            (x.status='reschedule_pending' and x.proposed_date=v_target_date
              and v_target_time < x.proposed_time + make_interval(mins => x.duration_minutes)
              and v_target_time + make_interval(mins => v_target_duration) > x.proposed_time)
          )
      ) then
        raise exception 'A duração escolhida causa conflito com outro agendamento. Ajuste a duração ou escolha outro horário.';
      end if;

      update public.bookings
        set booking_date=v_target_date, start_time=v_target_time, status='confirmed',
            duration_minutes=v_target_duration, proposed_date=null, proposed_time=null,
            admin_notes=coalesce(p_notes,admin_notes), updated_at=now()
        where id=p_booking_id;
    else
      update public.bookings
        set status=p_status, duration_minutes=coalesce(p_duration,duration_minutes),
            proposed_date=null, proposed_time=null,
            admin_notes=coalesce(p_notes,admin_notes), updated_at=now()
        where id=p_booking_id;
    end if;
    insert into public.studio_notifications(booking_id,title,message)
      values(p_booking_id,'Agendamento atualizado','O status foi alterado para '||p_status||'.');
  end if;
  return jsonb_build_object('success',true);
end;
$$;
revoke all on function public.admin_update_booking(uuid,text,date,time,integer,text) from public;
grant execute on function public.admin_update_booking(uuid,text,date,time,integer,text) to authenticated;

-- Storage: bucket público para as imagens públicas do portfólio.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('portfolio','portfolio',true,8388608,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true,file_size_limit=8388608,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
drop policy if exists "public view portfolio images" on storage.objects;
create policy "public view portfolio images" on storage.objects for select using (bucket_id='portfolio');
drop policy if exists "authenticated upload portfolio images" on storage.objects;
create policy "authenticated upload portfolio images" on storage.objects for insert to authenticated with check (bucket_id='portfolio' and public.is_studio_admin());
drop policy if exists "authenticated update portfolio images" on storage.objects;
create policy "authenticated update portfolio images" on storage.objects for update to authenticated using (bucket_id='portfolio' and public.is_studio_admin()) with check (bucket_id='portfolio' and public.is_studio_admin());
drop policy if exists "authenticated delete portfolio images" on storage.objects;
create policy "authenticated delete portfolio images" on storage.objects for delete to authenticated using (bucket_id='portfolio' and public.is_studio_admin());

-- Referências de clientes: bucket privado. O visitante pode enviar um arquivo associado a uma solicitação;
-- somente usuários autenticados conseguem criar links assinados e visualizar/excluir as referências.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('booking-references','booking-references',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=false,file_size_limit=5242880,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
drop policy if exists "public upload booking references" on storage.objects;
create policy "public upload booking references" on storage.objects for insert to anon, authenticated with check (bucket_id='booking-references');
drop policy if exists "admin read booking references" on storage.objects;
create policy "admin read booking references" on storage.objects for select to authenticated using (bucket_id='booking-references' and public.is_studio_admin());
drop policy if exists "admin delete booking references" on storage.objects;
create policy "admin delete booking references" on storage.objects for delete to authenticated using (bucket_id='booking-references' and public.is_studio_admin());


insert into public.studio_settings(id,artist_name,short_bio,bio,specialties)
values(1,'Studio Dronov','Tatuagens, piercing e criações autorais com atenção aos detalhes. Explore o portfólio e agende seu atendimento.','O Studio Dronov é um espaço de tatuagem e piercing em Cassilândia/MS, com projetos tratados com cuidado, técnica e atenção aos detalhes.','Tatuagem,Piercing,Arte autoral')
on conflict (id) do nothing;

-- Dados de contato visíveis no perfil informado pelo proprietário.
update public.studio_settings
set artist_name = case when artist_name is null or artist_name = 'INK STUDIO' then 'Studio Dronov' else artist_name end,
    whatsapp = coalesce(nullif(whatsapp,''),'556781801717'),
    address = coalesce(nullif(address,''),'Rua Ricardo Dutra de Oliveira, 555, Cassilândia/MS, 79540-000, Brasil')
where id=1;

-- IMPORTANTE: atribua app_metadata.studio_role = admin somente ao usuário proprietário.
-- Não use user_metadata para autorização: o próprio usuário pode alterá-lo.


-- ================================================================
-- ATUALIZAÇÃO: RANKING PRIVADO DE TATUAGENS + FINANCEIRO COMPLETO
-- Seguro para executar depois do bloco principal e também em upgrades.
-- ================================================================

-- Métricas são mantidas em tabela separada: o público NUNCA recebe contagens.
create table if not exists public.portfolio_metrics (
  portfolio_id uuid primary key references public.portfolio(id) on delete cascade,
  open_count bigint not null default 0 check (open_count >= 0),
  last_opened_at timestamptz not null default now()
);
alter table public.portfolio_metrics enable row level security;
drop policy if exists "admin read private portfolio metrics" on public.portfolio_metrics;
create policy "admin read private portfolio metrics" on public.portfolio_metrics
  for select to authenticated using (public.is_studio_admin());

create or replace function public.record_portfolio_open(p_portfolio_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_portfolio_id is null then return; end if;
  insert into public.portfolio_metrics as pm(portfolio_id,open_count,last_opened_at)
  select p.id,1,now()
  from public.portfolio p
  where p.id=p_portfolio_id and p.is_published=true and p.content_type='tattoo'
  on conflict (portfolio_id) do update
    set open_count=pm.open_count+1,
        last_opened_at=now();
end;
$$;
revoke all on function public.record_portfolio_open(uuid) from public;
grant execute on function public.record_portfolio_open(uuid) to anon, authenticated;

create or replace function public.admin_portfolio_ranking(p_limit integer default 12)
returns table(id uuid,title text,category text,image_url text,open_count bigint,last_opened_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_studio_admin() then
    raise exception 'Acesso administrativo não autorizado.';
  end if;
  return query
    select p.id,p.title,p.category,p.image_url,coalesce(m.open_count,0)::bigint,m.last_opened_at
    from public.portfolio p
    left join public.portfolio_metrics m on m.portfolio_id=p.id
    where p.is_published=true and p.content_type='tattoo'
    order by coalesce(m.open_count,0) desc, m.last_opened_at desc nulls last, p.created_at desc
    limit greatest(1,least(coalesce(p_limit,12),50));
end;
$$;
revoke all on function public.admin_portfolio_ranking(integer) from public;
grant execute on function public.admin_portfolio_ranking(integer) to authenticated;

-- Livro-caixa: receitas, despesas, pendências, vencimentos e vínculo opcional a agendamentos.
create table if not exists public.financial_transactions (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('income','expense')),
  description text not null check (length(trim(description)) between 1 and 140),
  category text not null default 'Outros',
  amount numeric(12,2) not null check (amount > 0),
  transaction_date date not null default current_date,
  due_date date,
  payment_method text not null default 'other' check (payment_method in ('pix','cash','credit_card','debit_card','transfer','other')),
  status text not null default 'paid' check (status in ('paid','pending')),
  client_name text,
  booking_id uuid references public.bookings(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid default auth.uid()
);
create index if not exists financial_transactions_date_idx on public.financial_transactions(transaction_date desc);
create index if not exists financial_transactions_status_type_idx on public.financial_transactions(status,type);
create index if not exists financial_transactions_booking_idx on public.financial_transactions(booking_id);
alter table public.financial_transactions enable row level security;
drop policy if exists "admin manage financial transactions" on public.financial_transactions;
create policy "admin manage financial transactions" on public.financial_transactions
  for all to authenticated using (public.is_studio_admin()) with check (public.is_studio_admin());

-- Exclusão segura de agendamento concluído: preserva valor/data/forma/status no livro-caixa,
-- mas remove o vínculo, nome e notas pessoais associados ao cliente.
create or replace function public.admin_delete_completed_booking(p_booking_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_reference_path text;
begin
  if not public.is_studio_admin() then
    raise exception 'Acesso administrativo obrigatório.';
  end if;
  select reference_path into v_reference_path
    from public.bookings
    where id=p_booking_id and status='completed'
    for update;
  if not found then
    return jsonb_build_object('success',false,'message','Somente agendamentos concluídos podem ser excluídos.');
  end if;
  update public.financial_transactions
     set booking_id=null, client_name=null, notes=null,
       description=case when type='income' then coalesce(nullif(category,''),'Atendimento') || ' concluído' else description end,
       updated_at=now()
   where booking_id=p_booking_id;
  delete from public.bookings where id=p_booking_id and status='completed';
  return jsonb_build_object('success',true,'reference_path',v_reference_path);
end;
$$;
revoke all on function public.admin_delete_completed_booking(uuid) from public;
grant execute on function public.admin_delete_completed_booking(uuid) to authenticated;


-- Não existem policies para anon/public nas tabelas privadas de métricas e finanças.


-- Carrossel público: exibe tatuagens ordenadas pelo total de aberturas, sem expor as métricas.
-- Não retorna contagens, posições ou qualquer coluna da tabela privada de métricas.
create or replace function public.public_featured_tattoos(p_limit integer default 10)
returns table(id uuid,title text,category text,image_url text,description text)
language sql
security definer
set search_path = public, pg_temp
stable
as $$
  select p.id,p.title,p.category,p.image_url,p.description
  from public.portfolio p
  left join public.portfolio_metrics m on m.portfolio_id=p.id
  where p.is_published=true and p.content_type='tattoo'
  order by coalesce(m.open_count,0) desc, m.last_opened_at desc nulls last, p.created_at desc
  limit greatest(1,least(coalesce(p_limit,10),20));
$$;
revoke all on function public.public_featured_tattoos(integer) from public;
grant execute on function public.public_featured_tattoos(integer) to anon, authenticated;

-- REALTIME: habilita notificações instantâneas no painel administrativo.
-- Se a tabela já estiver na publicação, não altera nada.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'studio_notifications'
  ) then
    alter publication supabase_realtime add table public.studio_notifications;
  end if;
exception when undefined_object then
  raise notice 'A publicação supabase_realtime não existe neste projeto; habilite Realtime para public.studio_notifications no Dashboard.';
end $$;


-- Política de sinal configurável pelo estúdio (percentual e ativação).
alter table public.studio_settings add column if not exists deposit_enabled boolean not null default false;
alter table public.studio_settings add column if not exists deposit_percentage integer not null default 30 check (deposit_percentage between 1 and 100);
